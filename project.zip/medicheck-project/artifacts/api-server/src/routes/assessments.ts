import { Router, type IRouter } from "express";
import { eq, desc, gte, count, sql } from "drizzle-orm";
import { db, assessmentsTable, drugInteractionsTable } from "@workspace/db";
import {
  CreateAssessmentBody,
  GetAssessmentParams,
  GetAssessmentResponse,
  ListAssessmentsResponse,
  GetAssessmentSummaryResponse,
} from "@workspace/api-zod";
import { analyzeSymptoms } from "../lib/analysis-engine";

const router: IRouter = Router();

router.get("/assessments/summary", async (req, res): Promise<void> => {
  const allAssessments = await db.select().from(assessmentsTable).orderBy(desc(assessmentsTable.createdAt));

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const totalAssessments = allAssessments.length;
  const todayCount = allAssessments.filter(a => new Date(a.createdAt) >= today).length;
  const severeCount = allAssessments.filter(a => a.overallSeverity === "severe").length;
  const referralCount = allAssessments.filter(a => a.referralRecommended).length;

  const conditionMap: Record<string, number> = {};
  const severityMap: Record<string, number> = {};

  for (const assessment of allAssessments) {
    const results = assessment.results as Array<{ condition: string; probability: number }>;
    if (results && results.length > 0) {
      const top = results.reduce((a, b) => (a.probability > b.probability ? a : b));
      conditionMap[top.condition] = (conditionMap[top.condition] || 0) + 1;
    }
    const sev = assessment.overallSeverity;
    severityMap[sev] = (severityMap[sev] || 0) + 1;
  }

  const conditionBreakdown = Object.entries(conditionMap).map(([condition, count]) => ({ condition, count }));
  const severityBreakdown = Object.entries(severityMap).map(([severity, count]) => ({ severity, count }));
  const recentAssessments = allAssessments.slice(0, 5);

  res.json(
    GetAssessmentSummaryResponse.parse({
      totalAssessments,
      todayCount,
      severeCount,
      referralCount,
      conditionBreakdown,
      severityBreakdown,
      recentAssessments,
    })
  );
});

router.get("/assessments", async (_req, res): Promise<void> => {
  const rows = await db.select().from(assessmentsTable).orderBy(desc(assessmentsTable.createdAt));
  res.json(ListAssessmentsResponse.parse(rows));
});

router.post("/assessments", async (req, res): Promise<void> => {
  const parsed = CreateAssessmentBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid assessment body");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { patientInfo, chronicDiseases, symptoms, currentMedications, drugAllergies, notes } = parsed.data;

  const { results, redFlagsDetected, referralRecommended, overallSeverity } = analyzeSymptoms(
    symptoms as Parameters<typeof analyzeSymptoms>[0],
    patientInfo as Parameters<typeof analyzeSymptoms>[1],
    chronicDiseases as Parameters<typeof analyzeSymptoms>[2],
    currentMedications,
    drugAllergies
  );

  const allInteractions = await db.select().from(drugInteractionsTable);
  const medsLower = currentMedications.map(m => m.toLowerCase());
  const interactions = allInteractions.filter(interaction => {
    const a = interaction.drugA.toLowerCase();
    const b = interaction.drugB.toLowerCase();
    const hasA = medsLower.some(m => m.includes(a) || a.includes(m));
    const hasB = medsLower.some(m => m.includes(b) || b.includes(m));
    return hasA && hasB;
  });

  const [assessment] = await db
    .insert(assessmentsTable)
    .values({
      patientInfo,
      chronicDiseases,
      symptoms,
      currentMedications,
      drugAllergies,
      results,
      interactions,
      redFlagsDetected,
      referralRecommended,
      overallSeverity,
      notes: notes ?? null,
    })
    .returning();

  res.status(201).json(GetAssessmentResponse.parse(assessment));
});

router.get("/assessments/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetAssessmentParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [assessment] = await db
    .select()
    .from(assessmentsTable)
    .where(eq(assessmentsTable.id, params.data.id));

  if (!assessment) {
    res.status(404).json({ error: "Assessment not found" });
    return;
  }

  res.json(GetAssessmentResponse.parse(assessment));
});

export default router;
