import { Router, type IRouter } from "express";
import { like, or, ilike } from "drizzle-orm";
import { db, medicationsTable } from "@workspace/db";
import { ListMedicationsQueryParams, ListMedicationsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/medications", async (req, res): Promise<void> => {
  const params = ListMedicationsQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  let rows;
  if (params.data.q && params.data.q.trim().length > 0) {
    const term = `%${params.data.q}%`;
    rows = await db
      .select()
      .from(medicationsTable)
      .where(
        or(
          ilike(medicationsTable.name, term),
          ilike(medicationsTable.genericName, term)
        )
      );
  } else {
    rows = await db.select().from(medicationsTable);
  }

  res.json(ListMedicationsResponse.parse(rows));
});

export default router;
