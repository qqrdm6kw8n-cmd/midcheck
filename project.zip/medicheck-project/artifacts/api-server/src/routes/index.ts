import { Router, type IRouter } from "express";
import healthRouter from "./health";
import medicationsRouter from "./medications";
import interactionsRouter from "./interactions";
import assessmentsRouter from "./assessments";

const router: IRouter = Router();

router.use(healthRouter);
router.use(medicationsRouter);
router.use(interactionsRouter);
router.use(assessmentsRouter);

export default router;
