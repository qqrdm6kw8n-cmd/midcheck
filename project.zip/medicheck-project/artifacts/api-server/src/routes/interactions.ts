import { Router, type IRouter } from "express";
import { or, and, ilike } from "drizzle-orm";
import { db, drugInteractionsTable } from "@workspace/db";
import { CheckInteractionsBody, CheckInteractionsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/interactions/check", async (req, res): Promise<void> => {
  const parsed = CheckInteractionsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const meds = parsed.data.medications;
  if (meds.length < 2) {
    res.json(CheckInteractionsResponse.parse([]));
    return;
  }

  const allInteractions = await db.select().from(drugInteractionsTable);

  const medsLower = meds.map(m => m.toLowerCase());
  const found = allInteractions.filter(interaction => {
    const a = interaction.drugA.toLowerCase();
    const b = interaction.drugB.toLowerCase();
    const hasA = medsLower.some(m => m.includes(a) || a.includes(m));
    const hasB = medsLower.some(m => m.includes(b) || b.includes(m));
    return hasA && hasB;
  });

  res.json(CheckInteractionsResponse.parse(found));
});

export default router;
