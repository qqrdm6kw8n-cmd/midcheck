interface Symptoms {
  fever?: boolean;
  temperature?: number | null;
  runnyNose?: boolean;
  nasalCongestion?: boolean;
  sneezing?: boolean;
  itchyNose?: boolean;
  itchyEyes?: boolean;
  wateryEyes?: boolean;
  soreThroat?: boolean;
  cough?: boolean;
  dryOrProductiveCough?: string | null;
  sputumColor?: string | null;
  shortnessOfBreath?: boolean;
  wheezing?: boolean;
  headache?: boolean;
  musclePain?: boolean;
  fatigue?: boolean;
  chills?: boolean;
  chestPain?: boolean;
  symptomDurationDays?: number;
  symptomSeverity?: string;
}

interface ChronicDiseases {
  asthma?: boolean;
  diabetes?: boolean;
  hypertension?: boolean;
  heartDisease?: boolean;
  kidneyDisease?: boolean;
  liverDisease?: boolean;
}

interface PatientInfo {
  age?: number;
  gender?: string;
  isPregnant?: boolean;
  isSmoker?: boolean;
}

interface ConditionResult {
  condition: string;
  probability: number;
  severity: string;
  suggestedTreatments: string[];
  warnings: string[];
}

export function analyzeSymptoms(
  symptoms: Symptoms,
  patientInfo: PatientInfo,
  chronicDiseases: ChronicDiseases,
  currentMedications: string[],
  drugAllergies: string[]
): {
  results: ConditionResult[];
  redFlagsDetected: string[];
  referralRecommended: boolean;
  overallSeverity: string;
} {
  let allergyScore = 0;
  let coldScore = 0;
  let fluScore = 0;

  if (symptoms.sneezing) allergyScore += 20;
  if (symptoms.itchyEyes) allergyScore += 20;
  if (symptoms.itchyNose) allergyScore += 20;
  if (symptoms.wateryEyes) allergyScore += 15;
  if (!symptoms.fever) allergyScore += 10;
  if (symptoms.runnyNose) allergyScore += 10;
  if (symptoms.nasalCongestion) allergyScore += 5;

  if (symptoms.soreThroat) coldScore += 20;
  if (symptoms.runnyNose) coldScore += 20;
  if (symptoms.nasalCongestion) coldScore += 15;
  if (symptoms.cough) coldScore += 10;
  if (symptoms.fever && (symptoms.temperature == null || symptoms.temperature < 38.5)) coldScore += 15;
  if (symptoms.headache) coldScore += 10;
  if (!symptoms.musclePain) coldScore += 5;
  if (!symptoms.chills) coldScore += 5;

  if (symptoms.fever && (symptoms.temperature != null && symptoms.temperature >= 38.5)) fluScore += 25;
  if (symptoms.musclePain) fluScore += 20;
  if (symptoms.fatigue) fluScore += 15;
  if (symptoms.chills) fluScore += 15;
  if (symptoms.headache) fluScore += 10;
  if (symptoms.cough) fluScore += 10;
  if (symptoms.soreThroat) fluScore += 5;

  const total = allergyScore + coldScore + fluScore || 1;
  const allergyPct = Math.round((allergyScore / total) * 100);
  const coldPct = Math.round((coldScore / total) * 100);
  const fluPct = 100 - allergyPct - coldPct;

  const redFlags: string[] = [];
  if (symptoms.chestPain) redFlags.push("Chest pain detected");
  if (symptoms.shortnessOfBreath) redFlags.push("Shortness of breath reported");
  if (symptoms.wheezing) redFlags.push("Wheezing reported");
  if (symptoms.temperature != null && symptoms.temperature >= 39.5) redFlags.push(`High fever: ${symptoms.temperature}°C`);
  if (symptoms.symptomDurationDays != null && symptoms.symptomDurationDays > 10) redFlags.push(`Prolonged symptoms: ${symptoms.symptomDurationDays} days`);
  if (symptoms.sputumColor === "green" || symptoms.sputumColor === "brown") redFlags.push("Abnormal sputum color");

  const referralRecommended = redFlags.length > 0 || symptoms.symptomSeverity === "severe";

  let overallSeverity = symptoms.symptomSeverity || "mild";
  if (redFlags.length > 0) overallSeverity = "severe";
  else if (overallSeverity !== "severe" && (fluPct > 50 || (symptoms.temperature != null && symptoms.temperature >= 38.0))) overallSeverity = "moderate";

  const nsaidAllergy = drugAllergies.some(a => a.toLowerCase().includes("nsaid"));
  const antihistamineAllergy = drugAllergies.some(a => a.toLowerCase().includes("antihistamine"));

  const allergyTreatments: string[] = [];
  if (!antihistamineAllergy) allergyTreatments.push("Cetirizine (antihistamine)");
  if (!antihistamineAllergy) allergyTreatments.push("Loratadine (antihistamine)");
  allergyTreatments.push("Saline nasal spray");
  allergyTreatments.push("Nasal corticosteroid spray");

  const coldTreatments: string[] = [];
  coldTreatments.push("Paracetamol (for fever/pain relief)");
  if (!nsaidAllergy) coldTreatments.push("Ibuprofen (anti-inflammatory)");
  coldTreatments.push("Saline nasal spray");
  coldTreatments.push("Throat lozenges");
  if (symptoms.cough) coldTreatments.push("Dextromethorphan (cough suppressant)");

  const fluTreatments: string[] = [];
  fluTreatments.push("Paracetamol (for fever/pain relief)");
  if (!nsaidAllergy) fluTreatments.push("Ibuprofen (anti-inflammatory)");
  fluTreatments.push("Rest and adequate hydration");
  if (symptoms.cough) fluTreatments.push("Dextromethorphan (cough suppressant)");

  const allergyWarnings: string[] = [
    "Cetirizine may cause drowsiness — avoid driving or operating machinery.",
    "This app does not provide medical diagnosis. Consult a healthcare professional."
  ];
  if (patientInfo.isPregnant) allergyWarnings.push("Consult your doctor before taking any antihistamine during pregnancy.");

  const coldWarnings: string[] = [
    "Do not exceed the recommended dose of paracetamol.",
    "This app does not provide medical diagnosis. Consult a healthcare professional."
  ];
  if (chronicDiseases.kidneyDisease || chronicDiseases.liverDisease) {
    coldWarnings.push("Kidney or liver disease detected — consult a doctor before taking NSAIDs or paracetamol.");
  }

  const fluWarnings: string[] = [
    "Influenza symptoms require rest and monitoring.",
    "This app does not provide medical diagnosis. Consult a healthcare professional."
  ];
  if (chronicDiseases.asthma) fluWarnings.push("Asthma patients with flu symptoms should contact a doctor promptly.");

  const results: ConditionResult[] = [
    {
      condition: "Seasonal Allergy",
      probability: allergyPct,
      severity: allergyPct > 50 ? overallSeverity : "mild",
      suggestedTreatments: allergyTreatments,
      warnings: allergyWarnings,
    },
    {
      condition: "Common Cold",
      probability: coldPct,
      severity: coldPct > 50 ? overallSeverity : "mild",
      suggestedTreatments: coldTreatments,
      warnings: coldWarnings,
    },
    {
      condition: "Influenza",
      probability: fluPct,
      severity: fluPct > 50 ? overallSeverity : "mild",
      suggestedTreatments: fluTreatments,
      warnings: fluWarnings,
    },
  ].sort((a, b) => b.probability - a.probability);

  return {
    results,
    redFlagsDetected: redFlags,
    referralRecommended,
    overallSeverity,
  };
}
