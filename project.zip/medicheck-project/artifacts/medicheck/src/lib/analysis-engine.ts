interface Symptoms {
  fever?: boolean;
  temperature?: number | null;
  runnyNose?: boolean;
  nasalCongestion?: boolean;
  sneezing?: boolean;
  itchyNose?: boolean;
  itchyEyes?: boolean;
  wateryEyes?: boolean;
  soreThroat?: boolean;
  cough?: boolean;
  dryOrProductiveCough?: string | null;
  sputumColor?: string | null;
  shortnessOfBreath?: boolean;
  wheezing?: boolean;
  headache?: boolean;
  musclePain?: boolean;
  fatigue?: boolean;
  chills?: boolean;
  chestPain?: boolean;
  symptomDurationDays?: number;
  symptomSeverity?: string;
}

interface ConditionResult {
  condition: string;
  probability: number;
  severity: string;
  suggestedTreatments: string[];
  warnings: string[];
}

export function analyzeSymptoms(symptoms: Partial<Symptoms>): {
  results: ConditionResult[];
  redFlagsDetected: string[];
  referralRecommended: boolean;
  overallSeverity: "mild" | "moderate" | "severe";
} {
  const redFlags: string[] = [];
  let isSevere = false;

  if (symptoms.chestPain) { redFlags.push("Chest Pain"); isSevere = true; }
  if (symptoms.shortnessOfBreath) { redFlags.push("Shortness of Breath"); isSevere = true; }
  if (symptoms.temperature && symptoms.temperature > 39.5) { redFlags.push(`High Fever (${symptoms.temperature}°C)`); isSevere = true; }
  if (symptoms.symptomDurationDays && symptoms.symptomDurationDays > 10) { redFlags.push(`Prolonged Symptoms (${symptoms.symptomDurationDays} days)`); isSevere = true; }
  if (symptoms.wheezing && symptoms.symptomSeverity === "severe") { redFlags.push("Severe Wheezing"); isSevere = true; }
  if (symptoms.sputumColor === "green" || symptoms.sputumColor === "brown") { redFlags.push("Abnormal Sputum Color"); }

  const overallSeverity: "mild" | "moderate" | "severe" = isSevere
    ? "severe"
    : symptoms.symptomSeverity === "severe"
    ? "severe"
    : symptoms.symptomSeverity === "moderate"
    ? "moderate"
    : "mild";

  const referralRecommended = redFlags.length > 0 || overallSeverity === "severe";

  let allergyScore = 0;
  if (symptoms.sneezing) allergyScore += 30;
  if (symptoms.itchyEyes) allergyScore += 30;
  if (symptoms.itchyNose) allergyScore += 20;
  if (symptoms.wateryEyes) allergyScore += 20;
  if (symptoms.runnyNose && !symptoms.fever) allergyScore += 10;
  if (symptoms.fever) allergyScore -= 40;

  let coldScore = 0;
  if (symptoms.soreThroat) coldScore += 30;
  if (symptoms.runnyNose) coldScore += 25;
  if (symptoms.nasalCongestion) coldScore += 20;
  if (symptoms.cough) coldScore += 10;
  if (symptoms.fever && symptoms.temperature && symptoms.temperature < 38.5) coldScore += 10;
  if (symptoms.headache) coldScore += 5;

  let fluScore = 0;
  if (symptoms.fever && symptoms.temperature && symptoms.temperature >= 38.5) fluScore += 35;
  if (symptoms.musclePain) fluScore += 25;
  if (symptoms.fatigue) fluScore += 20;
  if (symptoms.chills) fluScore += 20;
  if (symptoms.headache) fluScore += 10;

  const rawTotal = Math.max(allergyScore + coldScore + fluScore, 1);
  const allergyPct = Math.round(Math.max(allergyScore, 0) / rawTotal * 100);
  const coldPct = Math.round(Math.max(coldScore, 0) / rawTotal * 100);
  const fluPct = 100 - allergyPct - coldPct;

  const results: ConditionResult[] = [
    {
      condition: "Seasonal Allergy",
      probability: allergyPct,
      severity: allergyPct >= 50 ? overallSeverity : "mild",
      suggestedTreatments: [
        "Cetirizine (antihistamine)",
        "Loratadine (antihistamine)",
        "Saline nasal spray",
        "Nasal corticosteroid spray (e.g. fluticasone)",
      ],
      warnings: [
        "Cetirizine may cause drowsiness — avoid driving or operating machinery.",
        "Consult a healthcare professional before starting any medication.",
      ],
    },
    {
      condition: "Common Cold",
      probability: coldPct,
      severity: coldPct >= 50 ? overallSeverity : "mild",
      suggestedTreatments: [
        "Paracetamol (for fever and pain relief)",
        "Ibuprofen (anti-inflammatory, if not contraindicated)",
        "Saline nasal spray",
        "Throat lozenges",
        "Dextromethorphan (cough suppressant, if cough present)",
      ],
      warnings: [
        "Do not exceed the recommended dose of paracetamol.",
        "Consult a healthcare professional if symptoms worsen or persist beyond 7 days.",
      ],
    },
    {
      condition: "Influenza",
      probability: fluPct,
      severity: fluPct >= 50 ? overallSeverity : "mild",
      suggestedTreatments: [
        "Paracetamol (for fever and body pain)",
        "Ibuprofen (anti-inflammatory, if not contraindicated)",
        "Rest and adequate hydration",
        "Dextromethorphan (cough suppressant, if cough present)",
      ],
      warnings: [
        "Seek medical attention if you have difficulty breathing, persistent chest pain, or confusion.",
        "Influenza can be serious — monitor symptoms closely.",
        "Consult a healthcare professional for proper evaluation.",
      ],
    },
  ].sort((a, b) => b.probability - a.probability);

  return { results, redFlagsDetected: redFlags, referralRecommended, overallSeverity };
}
