import { createContext, useContext, useState, ReactNode } from "react";

interface PatientInfo {
  age?: number;
  gender?: string;
  weight?: number | null;
  isPregnant?: boolean;
  isSmoker?: boolean;
}

interface ChronicDiseases {
  asthma?: boolean;
  diabetes?: boolean;
  hypertension?: boolean;
  heartDisease?: boolean;
  kidneyDisease?: boolean;
  liverDisease?: boolean;
}

interface Symptoms {
  fever?: boolean;
  temperature?: number | null;
  runnyNose?: boolean;
  nasalCongestion?: boolean;
  sneezing?: boolean;
  itchyNose?: boolean;
  itchyEyes?: boolean;
  wateryEyes?: boolean;
  soreThroat?: boolean;
  cough?: boolean;
  dryOrProductiveCough?: string | null;
  sputumColor?: string | null;
  shortnessOfBreath?: boolean;
  wheezing?: boolean;
  headache?: boolean;
  musclePain?: boolean;
  fatigue?: boolean;
  chills?: boolean;
  chestPain?: boolean;
  symptomDurationDays?: number;
  symptomSeverity?: string;
}

interface AssessmentContextType {
  patientInfo: Partial<PatientInfo>;
  setPatientInfo: (info: Partial<PatientInfo>) => void;
  chronicDiseases: Partial<ChronicDiseases>;
  setChronicDiseases: (diseases: Partial<ChronicDiseases>) => void;
  symptoms: Partial<Symptoms>;
  setSymptoms: (symptoms: Partial<Symptoms>) => void;
  currentMedications: string[];
  setCurrentMedications: (meds: string[]) => void;
  drugAllergies: string[];
  setDrugAllergies: (allergies: string[]) => void;
  reset: () => void;
}

const defaultContext: AssessmentContextType = {
  patientInfo: {},
  setPatientInfo: () => {},
  chronicDiseases: {},
  setChronicDiseases: () => {},
  symptoms: {},
  setSymptoms: () => {},
  currentMedications: [],
  setCurrentMedications: () => {},
  drugAllergies: [],
  setDrugAllergies: () => {},
  reset: () => {},
};

const AssessmentContext = createContext<AssessmentContextType>(defaultContext);

export const useAssessment = () => useContext(AssessmentContext);

export const AssessmentProvider = ({ children }: { children: ReactNode }) => {
  const [patientInfo, setPatientInfo] = useState<Partial<PatientInfo>>({});
  const [chronicDiseases, setChronicDiseases] = useState<Partial<ChronicDiseases>>({});
  const [symptoms, setSymptoms] = useState<Partial<Symptoms>>({});
  const [currentMedications, setCurrentMedications] = useState<string[]>([]);
  const [drugAllergies, setDrugAllergies] = useState<string[]>([]);

  const reset = () => {
    setPatientInfo({});
    setChronicDiseases({});
    setSymptoms({});
    setCurrentMedications([]);
    setDrugAllergies([]);
  };

  return (
    <AssessmentContext.Provider
      value={{
        patientInfo,
        setPatientInfo,
        chronicDiseases,
        setChronicDiseases,
        symptoms,
        setSymptoms,
        currentMedications,
        setCurrentMedications,
        drugAllergies,
        setDrugAllergies,
        reset,
      }}
    >
      {children}
    </AssessmentContext.Provider>
  );
};
