import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { AssessmentProvider } from "@/lib/assessment-context";
import { Layout } from "@/components/layout";
import NotFound from "@/pages/not-found";
import LandingPage from "@/pages/landing";
import DisclaimerPage from "@/pages/disclaimer";
import PatientInfoPage from "@/pages/assessment/patient";
import ConditionsPage from "@/pages/assessment/conditions";
import SymptomsPage from "@/pages/assessment/symptoms";
import MedicationsPage from "@/pages/assessment/medications";
import ResultsPage from "@/pages/assessment/results";
import PharmacistDashboard from "@/pages/pharmacist/dashboard";
import AssessmentDetailPage from "@/pages/pharmacist/assessment-detail";

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={LandingPage} />
        <Route path="/disclaimer" component={DisclaimerPage} />
        <Route path="/assessment/patient" component={PatientInfoPage} />
        <Route path="/assessment/conditions" component={ConditionsPage} />
        <Route path="/assessment/symptoms" component={SymptomsPage} />
        <Route path="/assessment/medications" component={MedicationsPage} />
        <Route path="/assessment/results" component={ResultsPage} />
        <Route path="/pharmacist" component={PharmacistDashboard} />
        <Route path="/pharmacist/assessment/:id" component={AssessmentDetailPage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <AssessmentProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <Router />
            </WouterRouter>
          </AssessmentProvider>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
