import { useLocation } from "wouter";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useAssessment } from "@/lib/assessment-context";
import { StepIndicator } from "./step-indicator";
import { ArrowRight, ArrowLeft, Stethoscope } from "lucide-react";

export default function SymptomsPage() {
  const [, setLocation] = useLocation();
  const { symptoms: savedSymptoms, setSymptoms } = useAssessment();

  const [data, setData] = useState({
    fever: savedSymptoms.fever || false,
    temperature: savedSymptoms.temperature || null,
    runnyNose: savedSymptoms.runnyNose || false,
    nasalCongestion: savedSymptoms.nasalCongestion || false,
    sneezing: savedSymptoms.sneezing || false,
    itchyNose: savedSymptoms.itchyNose || false,
    itchyEyes: savedSymptoms.itchyEyes || false,
    wateryEyes: savedSymptoms.wateryEyes || false,
    soreThroat: savedSymptoms.soreThroat || false,
    cough: savedSymptoms.cough || false,
    dryOrProductiveCough: savedSymptoms.dryOrProductiveCough || null,
    sputumColor: savedSymptoms.sputumColor || null,
    shortnessOfBreath: savedSymptoms.shortnessOfBreath || false,
    wheezing: savedSymptoms.wheezing || false,
    headache: savedSymptoms.headache || false,
    musclePain: savedSymptoms.musclePain || false,
    fatigue: savedSymptoms.fatigue || false,
    chills: savedSymptoms.chills || false,
    chestPain: savedSymptoms.chestPain || false,
    symptomDurationDays: savedSymptoms.symptomDurationDays || 1,
    symptomSeverity: savedSymptoms.symptomSeverity || "mild",
  });

  function toggle(key: keyof typeof data) {
    setData(prev => ({ ...prev, [key]: !prev[key as keyof typeof prev] }));
  }

  function handleNext() {
    setSymptoms(data);
    setLocation("/assessment/medications");
  }

  const SwitchRow = ({ label, field, description }: { label: string; field: keyof typeof data; description?: string }) => (
    <div className="flex items-center justify-between py-2.5 border-b last:border-b-0">
      <div>
        <Label className="text-sm font-semibold">{label}</Label>
        {description && <p className="text-xs text-muted-foreground">{description}</p>}
      </div>
      <Switch
        checked={Boolean(data[field])}
        onCheckedChange={() => toggle(field)}
        data-testid={`switch-${String(field)}`}
      />
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto">
      <StepIndicator currentStep={3} />
      <div className="space-y-4">

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2 mb-1">
              <Stethoscope className="w-5 h-5 text-primary" />
              <CardTitle>تقييم الأعراض</CardTitle>
            </div>
            <CardDescription>حدّد الأعراض التي تعاني منها حالياً.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              <SwitchRow label="حمى (ارتفاع درجة الحرارة)" field="fever" />
              {data.fever && (
                <div className="pr-4 pb-2 pt-1">
                  <Label className="text-xs text-muted-foreground mb-1 block">درجة الحرارة (°م)</Label>
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="مثال: 38.5"
                    value={data.temperature ?? ""}
                    onChange={e => setData(prev => ({ ...prev, temperature: e.target.value ? parseFloat(e.target.value) : null }))}
                    className="max-w-[140px]"
                    data-testid="input-temperature"
                  />
                </div>
              )}
              <SwitchRow label="سيلان الأنف" field="runnyNose" />
              <SwitchRow label="احتقان الأنف" field="nasalCongestion" />
              <SwitchRow label="العطس" field="sneezing" />
              <SwitchRow label="حكة في الأنف" field="itchyNose" />
              <SwitchRow label="حكة في العيون" field="itchyEyes" />
              <SwitchRow label="دموع العيون (عيون دامعة)" field="wateryEyes" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="space-y-1">
              <SwitchRow label="التهاب الحلق" field="soreThroat" />
              <SwitchRow label="السعال" field="cough" />
              {data.cough && (
                <div className="pr-4 pb-2 pt-1 space-y-3">
                  <div>
                    <Label className="text-xs text-muted-foreground mb-1 block">نوع السعال</Label>
                    <RadioGroup
                      value={data.dryOrProductiveCough || ""}
                      onValueChange={v => setData(prev => ({ ...prev, dryOrProductiveCough: v }))}
                      className="flex gap-4"
                    >
                      <div className="flex items-center gap-1.5">
                        <RadioGroupItem value="dry" id="cough-dry" />
                        <Label htmlFor="cough-dry" className="text-sm">جاف</Label>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <RadioGroupItem value="productive" id="cough-productive" />
                        <Label htmlFor="cough-productive" className="text-sm">مصحوب بالبلغم</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  {data.dryOrProductiveCough === "productive" && (
                    <div>
                      <Label className="text-xs text-muted-foreground mb-1 block">لون البلغم</Label>
                      <Select
                        value={data.sputumColor || ""}
                        onValueChange={v => setData(prev => ({ ...prev, sputumColor: v }))}
                      >
                        <SelectTrigger className="max-w-[220px]">
                          <SelectValue placeholder="اختر اللون" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="clear">شفاف / أبيض</SelectItem>
                          <SelectItem value="yellow">أصفر</SelectItem>
                          <SelectItem value="green">أخضر</SelectItem>
                          <SelectItem value="brown">بني / داكن</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              )}
              <SwitchRow label="ضيق التنفس" field="shortnessOfBreath" description="صعوبة في التنفس أو الشعور باللهاث" />
              <SwitchRow label="صفير التنفس" field="wheezing" description="صوت صفير عالي عند التنفس" />
              <SwitchRow label="ألم في الصدر" field="chestPain" description="ألم أو ضيق في منطقة الصدر" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="space-y-1">
              <SwitchRow label="الصداع" field="headache" />
              <SwitchRow label="آلام العضلات" field="musclePain" description="أوجاع الجسم وآلام العضلات" />
              <SwitchRow label="الإرهاق والتعب" field="fatigue" description="تعب غير معتاد أو إرهاق شديد" />
              <SwitchRow label="القشعريرة" field="chills" description="الارتجاف والشعور بالبرد" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 space-y-6">
            <div>
              <Label className="font-bold mb-2 block">
                مدة الأعراض: <span className="text-primary">{data.symptomDurationDays} {data.symptomDurationDays === 1 ? "يوم" : "أيام"}</span>
              </Label>
              <Slider
                min={1}
                max={21}
                step={1}
                value={[data.symptomDurationDays]}
                onValueChange={([v]) => setData(prev => ({ ...prev, symptomDurationDays: v }))}
                data-testid="slider-duration"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>يوم واحد</span>
                <span>3 أسابيع</span>
              </div>
              {data.symptomDurationDays > 10 && (
                <p className="text-xs text-destructive mt-1 font-bold">الأعراض المطوّلة قد تستدعي تقييماً طبياً</p>
              )}
            </div>

            <div>
              <Label className="font-bold mb-3 block">الشدة العامة للأعراض</Label>
              <RadioGroup
                value={data.symptomSeverity}
                onValueChange={v => setData(prev => ({ ...prev, symptomSeverity: v }))}
                className="flex gap-4"
                data-testid="radio-severity"
              >
                {[
                  { value: "mild", label: "خفيفة", color: "text-green-600" },
                  { value: "moderate", label: "متوسطة", color: "text-yellow-600" },
                  { value: "severe", label: "شديدة", color: "text-destructive" },
                ].map(({ value, label, color }) => (
                  <div
                    key={value}
                    className={`flex items-center gap-2 border rounded-lg px-4 py-2 cursor-pointer transition-colors ${
                      data.symptomSeverity === value ? "border-primary bg-primary/5" : "border-border"
                    }`}
                    onClick={() => setData(prev => ({ ...prev, symptomSeverity: value }))}
                  >
                    <RadioGroupItem value={value} id={`severity-${value}`} />
                    <Label htmlFor={`severity-${value}`} className={`${color} font-bold cursor-pointer`}>{label}</Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-between">
          <Button variant="outline" onClick={() => setLocation("/assessment/conditions")} data-testid="button-back">
            <ArrowRight className="ml-2 w-4 h-4" />
            رجوع
          </Button>
          <Button onClick={handleNext} data-testid="button-next-medications">
            <ArrowLeft className="ml-2 w-4 h-4" />
            متابعة
          </Button>
        </div>
      </div>
    </div>
  );
}
