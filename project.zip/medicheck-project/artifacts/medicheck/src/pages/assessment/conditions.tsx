import { useLocation } from "wouter";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useAssessment } from "@/lib/assessment-context";
import { StepIndicator } from "./step-indicator";
import { ArrowRight, ArrowLeft, Heart } from "lucide-react";

const CONDITIONS = [
  { key: "asthma", label: "الربو", description: "مرض مزمن في الجهاز التنفسي" },
  { key: "diabetes", label: "السكري", description: "داء السكري من النوع الأول أو الثاني" },
  { key: "hypertension", label: "ارتفاع ضغط الدم", description: "ضغط الدم المرتفع" },
  { key: "heartDisease", label: "أمراض القلب", description: "أمراض الشريان التاجي أو قصور القلب" },
  { key: "kidneyDisease", label: "أمراض الكلى", description: "مرض الكلى المزمن" },
  { key: "liverDisease", label: "أمراض الكبد", description: "مرض الكبد المزمن أو التهاب الكبد" },
] as const;

type ConditionKey = typeof CONDITIONS[number]["key"];

export default function ConditionsPage() {
  const [, setLocation] = useLocation();
  const { chronicDiseases, setChronicDiseases } = useAssessment();

  const [selected, setSelected] = useState<Record<ConditionKey, boolean>>({
    asthma: chronicDiseases.asthma || false,
    diabetes: chronicDiseases.diabetes || false,
    hypertension: chronicDiseases.hypertension || false,
    heartDisease: chronicDiseases.heartDisease || false,
    kidneyDisease: chronicDiseases.kidneyDisease || false,
    liverDisease: chronicDiseases.liverDisease || false,
  });

  function toggle(key: ConditionKey) {
    setSelected(prev => ({ ...prev, [key]: !prev[key] }));
  }

  function handleNext() {
    setChronicDiseases(selected);
    setLocation("/assessment/symptoms");
  }

  return (
    <div className="max-w-2xl mx-auto">
      <StepIndicator currentStep={2} />
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2 mb-1">
            <Heart className="w-5 h-5 text-primary" />
            <CardTitle>الأمراض المزمنة</CardTitle>
          </div>
          <CardDescription>
            حدّد أي أمراض مزمنة موجودة مسبقاً. يساعد ذلك في تحديد موانع الاستعمال ومخاطر الأدوية.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {CONDITIONS.map(({ key, label, description }) => (
              <div
                key={key}
                className={`flex items-start gap-3 p-4 rounded-lg border cursor-pointer transition-colors ${
                  selected[key] ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                }`}
                onClick={() => toggle(key)}
                data-testid={`condition-${key}`}
              >
                <Checkbox
                  checked={selected[key]}
                  onCheckedChange={() => toggle(key)}
                  className="mt-0.5"
                />
                <div>
                  <Label className="font-bold cursor-pointer">{label}</Label>
                  <p className="text-xs text-muted-foreground mt-0.5">{description}</p>
                </div>
              </div>
            ))}
          </div>

          <p className="text-xs text-muted-foreground mt-4 italic">
            إذا لم ينطبق عليك أي منها، اتركها دون تحديد وتابع.
          </p>

          <div className="flex justify-between mt-6">
            <Button variant="outline" onClick={() => setLocation("/assessment/patient")} data-testid="button-back">
              <ArrowRight className="ml-2 w-4 h-4" />
              رجوع
            </Button>
            <Button onClick={handleNext} data-testid="button-next-symptoms">
              <ArrowLeft className="ml-2 w-4 h-4" />
              متابعة
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
