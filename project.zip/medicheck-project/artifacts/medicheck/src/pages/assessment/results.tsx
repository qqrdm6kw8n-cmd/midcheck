import { useLocation } from "wouter";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useAssessment } from "@/lib/assessment-context";
import { analyzeSymptoms } from "@/lib/analysis-engine";
import { useCreateAssessment, useCheckInteractions } from "@workspace/api-client-react";
import { StepIndicator } from "./step-indicator";
import {
  AlertTriangle, CheckCircle, XCircle, Stethoscope, Pill,
  RefreshCw, ClipboardCheck, Info
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const SEVERITY_CONFIG = {
  mild: { label: "خفيفة", color: "text-green-600", bg: "bg-green-50 border-green-200 dark:bg-green-950/30 dark:border-green-800", icon: CheckCircle, iconColor: "text-green-600" },
  moderate: { label: "متوسطة", color: "text-yellow-600", bg: "bg-yellow-50 border-yellow-200 dark:bg-yellow-950/30 dark:border-yellow-800", icon: AlertTriangle, iconColor: "text-yellow-600" },
  severe: { label: "شديدة", color: "text-destructive", bg: "bg-red-50 border-red-200 dark:bg-red-950/30 dark:border-red-800", icon: XCircle, iconColor: "text-destructive" },
};

const INTERACTION_SEVERITY_CONFIG = {
  mild: { color: "border-blue-300 bg-blue-50 dark:bg-blue-950/30 dark:border-blue-800", badge: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200" },
  moderate: { color: "border-yellow-300 bg-yellow-50 dark:bg-yellow-950/30 dark:border-yellow-800", badge: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200" },
  severe: { color: "border-red-300 bg-red-50 dark:bg-red-950/30 dark:border-red-800", badge: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200" },
};

const CONDITION_NAMES: Record<string, string> = {
  "Seasonal Allergy": "حساسية موسمية",
  "Common Cold": "نزلة برد",
  "Influenza": "إنفلونزا",
};

const TREATMENT_TRANSLATIONS: Record<string, string> = {
  "Cetirizine (antihistamine)": "سيتيريزين (مضاد الهيستامين)",
  "Loratadine (antihistamine)": "لوراتادين (مضاد الهيستامين)",
  "Saline nasal spray": "محلول ملحي للأنف",
  "Nasal corticosteroid spray (e.g. fluticasone)": "بخاخ الكورتيكوستيرويد الأنفي (مثل فلوتيكازون)",
  "Paracetamol (for fever and pain relief)": "باراسيتامول (لخفض الحمى وتسكين الألم)",
  "Ibuprofen (anti-inflammatory, if not contraindicated)": "إيبوبروفين (مضاد الالتهاب، إن لم يكن ممنوعاً)",
  "Throat lozenges": "أقراص تحلّ في الفم لتهدئة الحلق",
  "Dextromethorphan (cough suppressant, if cough present)": "ديكستروميثورفان (مثبّط السعال)",
  "Rest and adequate hydration": "الراحة والإكثار من السوائل",
};

const WARNING_TRANSLATIONS: Record<string, string> = {
  "Cetirizine may cause drowsiness — avoid driving or operating machinery.": "سيتيريزين قد يسبب النعاس — تجنب قيادة السيارة أو تشغيل الآلات.",
  "Consult a healthcare professional before starting any medication.": "استشر مختص الرعاية الصحية قبل البدء بأي دواء.",
  "Do not exceed the recommended dose of paracetamol.": "لا تتجاوز الجرعة الموصى بها من الباراسيتامول.",
  "Consult a healthcare professional if symptoms worsen or persist beyond 7 days.": "استشر الطبيب إذا تفاقمت الأعراض أو استمرت أكثر من 7 أيام.",
  "Seek medical attention if you have difficulty breathing, persistent chest pain, or confusion.": "اطلب الرعاية الطبية فوراً إذا عانيت من صعوبة في التنفس أو ألم صدر مستمر أو تشوش.",
  "Influenza can be serious — monitor symptoms closely.": "الإنفلونزا قد تكون خطيرة — راقب الأعراض عن كثب.",
  "Consult a healthcare professional for proper evaluation.": "استشر مختصاً للحصول على تقييم سليم.",
};

const REDFLAG_TRANSLATIONS: Record<string, string> = {
  "Chest Pain": "ألم في الصدر",
  "Shortness of Breath": "ضيق التنفس",
  "Severe Wheezing": "صفير تنفس شديد",
  "Abnormal Sputum Color": "لون بلغم غير طبيعي",
  "Prolonged Symptoms": "أعراض مطوّلة",
};

function translateRedFlag(flag: string) {
  for (const [en, ar] of Object.entries(REDFLAG_TRANSLATIONS)) {
    if (flag.startsWith(en)) return flag.replace(en, ar);
  }
  return flag;
}

export default function ResultsPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { patientInfo, chronicDiseases, symptoms, currentMedications, drugAllergies, reset } = useAssessment();
  const [saved, setSaved] = useState(false);

  const analysisResult = analyzeSymptoms(symptoms);
  const checkInteractions = useCreateAssessment();
  const createAssessment = useCreateAssessment();
  const checkInt = useCheckInteractions();

  const [interactions, setInteractions] = useState<Array<{ drugA: string; drugB: string; severity: string; message: string }>>([]);
  const [interactionChecked, setInteractionChecked] = useState(false);

  if (!interactionChecked && currentMedications.length >= 2) {
    setInteractionChecked(true);
    checkInt.mutate(
      { data: { medications: currentMedications } },
      { onSuccess: (data) => setInteractions(data as typeof interactions) }
    );
  }

  const { results, redFlagsDetected, referralRecommended, overallSeverity } = analysisResult;
  const sevConfig = SEVERITY_CONFIG[overallSeverity as keyof typeof SEVERITY_CONFIG];
  const SevIcon = sevConfig.icon;

  function handleSave() {
    if (!patientInfo.age || !patientInfo.gender) {
      toast({ title: "بيانات ناقصة", description: "يرجى إكمال جميع الخطوات قبل الحفظ.", variant: "destructive" });
      return;
    }
    createAssessment.mutate(
      {
        data: {
          patientInfo: { age: patientInfo.age!, gender: patientInfo.gender! as "male" | "female" | "other", weight: patientInfo.weight, isPregnant: patientInfo.isPregnant || false, isSmoker: patientInfo.isSmoker || false },
          chronicDiseases,
          symptoms: { ...symptoms, symptomDurationDays: symptoms.symptomDurationDays || 1, symptomSeverity: symptoms.symptomSeverity || "mild" },
          currentMedications,
          drugAllergies,
          notes: null,
        },
      },
      {
        onSuccess: () => {
          setSaved(true);
          toast({ title: "تم الحفظ", description: "تم حفظ التقييم بنجاح." });
        },
        onError: () => {
          toast({ title: "فشل الحفظ", description: "تعذّر حفظ التقييم. حاول مرة أخرى.", variant: "destructive" });
        },
      }
    );
  }

  function handleRestart() {
    reset();
    setLocation("/disclaimer");
  }

  return (
    <div className="max-w-2xl mx-auto">
      <StepIndicator currentStep={5} />

      <div className="space-y-4">
        <div className={`border rounded-xl p-5 ${sevConfig.bg}`} data-testid="overall-severity">
          <div className="flex items-center gap-3 mb-1">
            <SevIcon className={`w-6 h-6 ${sevConfig.iconColor}`} />
            <div>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide">الشدة الإجمالية</p>
              <p className={`text-xl font-extrabold ${sevConfig.color}`}>{sevConfig.label}</p>
            </div>
          </div>
          {referralRecommended && (
            <div className="mt-3 flex items-start gap-2 bg-destructive/10 border border-destructive/30 rounded-lg p-3">
              <AlertTriangle className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" />
              <p className="text-sm font-bold text-destructive">
                يُنصح بمراجعة الطبيب. يرجى استشارة مختص الرعاية الصحية في أقرب وقت.
              </p>
            </div>
          )}
        </div>

        <div className="border rounded-xl p-4 bg-muted/30">
          <div className="flex items-center gap-2 mb-2">
            <Info className="w-4 h-4 text-primary" />
            <p className="text-xs font-bold text-primary uppercase tracking-wide">إخلاء المسؤولية الطبية</p>
          </div>
          <p className="text-xs text-muted-foreground">
            هذه ليست نتيجة تشخيص طبي. النتائج مبنية على تحليل قائم على قواعد وهي لأغراض إعلامية فقط.
            استشر دائماً مختصاً في الرعاية الصحية قبل تناول أي دواء.
          </p>
        </div>

        {redFlagsDetected.length > 0 && (
          <Card className="border-destructive">
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2 text-destructive">
                <XCircle className="w-4 h-4" />
                أعراض خطيرة تستدعي الانتباه
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-1">
                {redFlagsDetected.map(flag => (
                  <li key={flag} className="text-sm flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-destructive flex-shrink-0" />
                    {translateRedFlag(flag)}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-primary" />
              الحالات المحتملة
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {results.length === 0 ? (
              <p className="text-sm text-muted-foreground">لم يُكتشف نمط حالة محدد. يرجى إدخال المزيد من الأعراض.</p>
            ) : (
              results.map(result => {
                const rSev = SEVERITY_CONFIG[result.severity as keyof typeof SEVERITY_CONFIG];
                const arabicName = CONDITION_NAMES[result.condition] || result.condition;
                return (
                  <div key={result.condition} className="space-y-2" data-testid={`result-${result.condition.replace(/\s/g, "-")}`}>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm">{arabicName}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={rSev.color}>{rSev.label}</Badge>
                        <span className="text-sm font-extrabold text-primary">{result.probability}%</span>
                      </div>
                    </div>
                    <Progress value={result.probability} className="h-2" />

                    {result.suggestedTreatments.length > 0 && (
                      <div className="pr-3 border-r-2 border-secondary/40 text-xs space-y-1">
                        <p className="font-bold text-muted-foreground uppercase tracking-wide text-[10px]">العلاج الداعم المقترح</p>
                        {result.suggestedTreatments.map(t => (
                          <p key={t} className="text-foreground/80">{TREATMENT_TRANSLATIONS[t] || t}</p>
                        ))}
                      </div>
                    )}

                    {result.warnings.length > 0 && (
                      <div className="space-y-1">
                        {result.warnings.filter(w => !w.includes("NOT a medical")).map(w => (
                          <div key={w} className="flex items-start gap-1.5 text-xs text-yellow-700 dark:text-yellow-400">
                            <AlertTriangle className="w-3 h-3 flex-shrink-0 mt-0.5" />
                            {WARNING_TRANSLATIONS[w] || w}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>

        {interactions.length > 0 && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Pill className="w-4 h-4 text-primary" />
                تنبيهات التفاعلات الدوائية
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {interactions.map((interaction, i) => {
                const cfg = INTERACTION_SEVERITY_CONFIG[interaction.severity as keyof typeof INTERACTION_SEVERITY_CONFIG];
                const sevLabels: Record<string, string> = { mild: "خفيف", moderate: "متوسط", severe: "شديد" };
                return (
                  <div key={i} className={`border rounded-lg p-3 ${cfg.color}`} data-testid={`interaction-${i}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-bold">{interaction.drugA} + {interaction.drugB}</span>
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${cfg.badge}`}>
                        {sevLabels[interaction.severity] || interaction.severity}
                      </span>
                    </div>
                    <p className="text-xs opacity-80">{interaction.message}</p>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        )}

        <div className="flex gap-3 justify-between">
          <Button variant="outline" onClick={handleRestart} data-testid="button-restart">
            <RefreshCw className="ml-2 w-4 h-4" />
            تقييم جديد
          </Button>
          <Button
            onClick={handleSave}
            disabled={saved || createAssessment.isPending}
            data-testid="button-save"
          >
            <ClipboardCheck className="ml-2 w-4 h-4" />
            {saved ? "تم الحفظ" : createAssessment.isPending ? "جارٍ الحفظ..." : "حفظ التقييم"}
          </Button>
        </div>
      </div>
    </div>
  );
}
