import { useLocation } from "wouter";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useAssessment } from "@/lib/assessment-context";
import { StepIndicator } from "./step-indicator";
import { ArrowRight, ArrowLeft, Pill, Search, X, ShieldAlert } from "lucide-react";
import { useListMedications } from "@workspace/api-client-react";

const ALLERGY_OPTIONS = [
  { key: "Penicillin", label: "البنسلين" },
  { key: "NSAIDs", label: "مضادات الالتهاب اللاستيرويدية (كالإيبوبروفين والأسبرين)" },
  { key: "Antihistamines", label: "مضادات الهيستامين" },
  { key: "Other", label: "أخرى (يُرجى ذكرها في الملاحظات)" },
];

export default function MedicationsPage() {
  const [, setLocation] = useLocation();
  const { currentMedications, setCurrentMedications, drugAllergies, setDrugAllergies } = useAssessment();

  const [meds, setMeds] = useState<string[]>(currentMedications);
  const [allergies, setAllergies] = useState<string[]>(drugAllergies);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);

  const { data: medicationsData } = useListMedications(
    searchQuery.length > 1 ? { q: searchQuery } : undefined
  );

  const suggestions = medicationsData || [];

  function addMedication(name: string) {
    if (!meds.includes(name)) {
      setMeds(prev => [...prev, name]);
    }
    setSearchQuery("");
    setShowSuggestions(false);
  }

  function removeMedication(name: string) {
    setMeds(prev => prev.filter(m => m !== name));
  }

  function toggleAllergy(key: string) {
    setAllergies(prev => prev.includes(key) ? prev.filter(a => a !== key) : [...prev, key]);
  }

  function handleAddCustom() {
    const trimmed = searchQuery.trim();
    if (trimmed && !meds.includes(trimmed)) {
      addMedication(trimmed);
    }
  }

  function handleNext() {
    setCurrentMedications(meds);
    setDrugAllergies(allergies);
    setLocation("/assessment/results");
  }

  return (
    <div className="max-w-2xl mx-auto">
      <StepIndicator currentStep={4} />
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2 mb-1">
              <Pill className="w-5 h-5 text-primary" />
              <CardTitle>الأدوية الحالية</CardTitle>
            </div>
            <CardDescription>
              أدرج جميع الأدوية التي تتناولها حالياً. يُتيح ذلك فحص التفاعلات الدوائية.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    className="pr-9"
                    placeholder="ابحث عن اسم الدواء..."
                    value={searchQuery}
                    onChange={e => {
                      setSearchQuery(e.target.value);
                      setShowSuggestions(true);
                    }}
                    onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                    data-testid="input-medication-search"
                  />
                </div>
                <Button variant="outline" onClick={handleAddCustom} disabled={!searchQuery.trim()} data-testid="button-add-medication">
                  إضافة
                </Button>
              </div>

              {showSuggestions && suggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 z-50 bg-background border rounded-md shadow-md mt-1 max-h-48 overflow-y-auto">
                  {suggestions.map(med => (
                    <button
                      key={med.id}
                      className="w-full text-right px-4 py-2 text-sm hover:bg-accent flex items-center justify-between"
                      onMouseDown={() => addMedication(med.name)}
                    >
                      <span className="text-xs text-muted-foreground">{med.category}</span>
                      <span className="font-bold">{med.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {meds.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {meds.map(med => (
                  <Badge key={med} variant="secondary" className="pl-2 pr-3 py-1 text-sm gap-1" data-testid={`badge-med-${med}`}>
                    <button
                      onClick={() => removeMedication(med)}
                      className="mr-1 hover:text-destructive transition-colors"
                      data-testid={`remove-med-${med}`}
                    >
                      <X className="w-3 h-3" />
                    </button>
                    {med}
                  </Badge>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground italic">لم تُضف أي أدوية بعد.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2 mb-1">
              <ShieldAlert className="w-5 h-5 text-primary" />
              <CardTitle>الحساسية الدوائية</CardTitle>
            </div>
            <CardDescription>حدّد أي حساسية دوائية معروفة لديك.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {ALLERGY_OPTIONS.map(({ key, label }) => (
                <div
                  key={key}
                  className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                    allergies.includes(key) ? "border-destructive bg-destructive/5" : "border-border hover:border-destructive/40"
                  }`}
                  onClick={() => toggleAllergy(key)}
                  data-testid={`allergy-${key}`}
                >
                  <Checkbox
                    checked={allergies.includes(key)}
                    onCheckedChange={() => toggleAllergy(key)}
                  />
                  <Label className="cursor-pointer font-semibold">{label}</Label>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-between">
          <Button variant="outline" onClick={() => setLocation("/assessment/symptoms")} data-testid="button-back">
            <ArrowRight className="ml-2 w-4 h-4" />
            رجوع
          </Button>
          <Button onClick={handleNext} data-testid="button-view-results">
            <ArrowLeft className="ml-2 w-4 h-4" />
            عرض النتائج
          </Button>
        </div>
      </div>
    </div>
  );
}
