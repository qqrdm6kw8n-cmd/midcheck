import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useAssessment } from "@/lib/assessment-context";
import { StepIndicator } from "./step-indicator";
import { ArrowLeft, User } from "lucide-react";

const schema = z.object({
  age: z.coerce.number().min(1).max(120),
  gender: z.enum(["male", "female", "other"]),
  weight: z.coerce.number().min(1).max(500).optional().or(z.literal("")),
  isPregnant: z.boolean().default(false),
  isSmoker: z.boolean().default(false),
});

type FormValues = z.infer<typeof schema>;

export default function PatientInfoPage() {
  const [, setLocation] = useLocation();
  const { patientInfo, setPatientInfo } = useAssessment();

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      age: (patientInfo.age as number) || undefined,
      gender: (patientInfo.gender as "male" | "female" | "other") || undefined,
      weight: (patientInfo.weight as number) || "",
      isPregnant: patientInfo.isPregnant || false,
      isSmoker: patientInfo.isSmoker || false,
    },
  });

  const genderValue = form.watch("gender");

  function onSubmit(values: FormValues) {
    setPatientInfo({
      age: values.age,
      gender: values.gender,
      weight: values.weight ? Number(values.weight) : null,
      isPregnant: values.isPregnant,
      isSmoker: values.isSmoker,
    });
    setLocation("/assessment/conditions");
  }

  return (
    <div className="max-w-2xl mx-auto">
      <StepIndicator currentStep={1} />
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2 mb-1">
            <User className="w-5 h-5 text-primary" />
            <CardTitle>بيانات المريض</CardTitle>
          </div>
          <CardDescription>
            تساعد هذه المعلومات في تخصيص التقييم وتحديد عوامل الخطر المناسبة.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="age"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>العمر <span className="text-destructive">*</span></FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="مثال: 35" {...field} data-testid="input-age" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="gender"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الجنس <span className="text-destructive">*</span></FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-gender">
                            <SelectValue placeholder="اختر الجنس" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="male">ذكر</SelectItem>
                          <SelectItem value="female">أنثى</SelectItem>
                          <SelectItem value="other">آخر</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="weight"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الوزن (كجم) <span className="text-muted-foreground text-xs">اختياري</span></FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="مثال: 70" {...field} data-testid="input-weight" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {genderValue === "female" && (
                <FormField
                  control={form.control}
                  name="isPregnant"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base font-bold">حامل حالياً</FormLabel>
                        <p className="text-sm text-muted-foreground">مطلوب لتوصيات آمنة للأدوية</p>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-pregnant" />
                      </FormControl>
                    </FormItem>
                  )}
                />
              )}

              <FormField
                control={form.control}
                name="isSmoker"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base font-bold">مدخّن حالياً</FormLabel>
                      <p className="text-sm text-muted-foreground">مهم لتقييم أعراض الجهاز التنفسي</p>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-smoker" />
                    </FormControl>
                  </FormItem>
                )}
              />

              <div className="flex justify-start">
                <Button type="submit" data-testid="button-next-conditions">
                  <ArrowLeft className="ml-2 w-4 h-4" />
                  متابعة
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
