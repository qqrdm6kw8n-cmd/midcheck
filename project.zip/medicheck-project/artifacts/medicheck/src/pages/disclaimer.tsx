import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { AlertTriangle, ShieldCheck } from "lucide-react";

const DISCLAIMER_ITEMS = [
  "هذا التطبيق لا يُقدّم تشخيصاً طبياً ولا يُغني عن الاستشارة الطبية المتخصصة.",
  "جميع النتائج مبنية على تحليل قائم على قواعد وهي لأغراض إعلامية فقط.",
  "لا تستخدم هذه الأداة بديلاً عن الرعاية الطبية الطارئة. اتصل بالإسعاف فوراً في الحالات التي تهدد الحياة.",
  "هذه الأداة لا تصف مضادات حيوية أو أي أدوية تستلزم وصفة طبية.",
  "فحوصات التفاعلات الدوائية إرشادية فقط — تحقق دائماً مع صيدلاني أو طبيب مرخّص.",
  "قد لا تأخذ النتائج في الحسبان جميع العوامل الصحية الفردية. يجب استشارة مختص قبل تناول أي دواء.",
];

export default function DisclaimerPage() {
  const [, setLocation] = useLocation();
  const [agreed, setAgreed] = useState(false);

  return (
    <div className="max-w-2xl mx-auto py-4">
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2 mb-1">
            <ShieldCheck className="w-5 h-5 text-primary" />
            <CardTitle>إخلاء المسؤولية الطبية</CardTitle>
          </div>
          <p className="text-sm text-muted-foreground">
            يرجى قراءة ما يلي والموافقة عليه قبل المتابعة.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm font-bold text-amber-800 dark:text-amber-300">
                هذه الأداة ليست بديلاً عن المشورة الطبية المتخصصة أو التشخيص أو العلاج.
              </p>
            </div>
          </div>

          <ul className="space-y-3">
            {DISCLAIMER_ITEMS.map((item, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm">
                <span className="w-5 h-5 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                  {i + 1}
                </span>
                <span className="text-foreground/80">{item}</span>
              </li>
            ))}
          </ul>

          <div
            className="flex items-start gap-3 p-4 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors"
            onClick={() => setAgreed(!agreed)}
          >
            <Checkbox
              checked={agreed}
              onCheckedChange={(v) => setAgreed(Boolean(v))}
              id="agree-checkbox"
              data-testid="checkbox-agree"
            />
            <Label htmlFor="agree-checkbox" className="cursor-pointer text-sm font-semibold">
              أفهم وأوافق على أن هذه الأداة لا تُقدّم تشخيصاً طبياً ولا تُغني عن استشارة المختص.
            </Label>
          </div>

          <div className="flex justify-between items-center pt-2">
            <Button variant="outline" onClick={() => setLocation("/")} data-testid="button-cancel">
              رجوع
            </Button>
            <Button
              disabled={!agreed}
              onClick={() => setLocation("/assessment/patient")}
              data-testid="button-proceed"
            >
              المتابعة للتقييم
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
