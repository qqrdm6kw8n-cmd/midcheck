import { Link } from "wouter";
import { Activity, Shield, Pill, BarChart2, ChevronLeft, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const FEATURES = [
  { icon: Activity, label: "تحليل الأعراض", desc: "تقييم متعدد الخطوات للبرد والإنفلونزا والحساسية" },
  { icon: Shield, label: "فحص التفاعلات الدوائية", desc: "تنبيهات فورية للتفاعلات بين الأدوية" },
  { icon: AlertCircle, label: "الكشف عن الأعراض الخطيرة", desc: "يُحدد الأعراض الشديدة التي تستدعي رعاية عاجلة" },
  { icon: BarChart2, label: "لوحة الصيدلاني", desc: "مراجعة تقييمات المرضى والإحصائيات" },
];

export default function LandingPage() {
  return (
    <div className="flex flex-col gap-16 py-8">
      <section className="text-center max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 bg-primary/10 text-primary rounded-full px-4 py-1.5 text-sm font-semibold mb-6">
          <Activity className="w-4 h-4" />
          تقييم الأعراض الذكي
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-foreground mb-4 leading-tight">
          رفيقك الطبي<br className="hidden sm:block" /> في حياتك اليومية
        </h1>
        <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto">
          يحلّل ميديتشيك أعراضك، ويفحص التفاعلات الدوائية، ويقدّم إرشادات رعاية موثوقة — يثق به المرضى والصيادلة.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="/disclaimer">
            <Button size="lg" className="w-full sm:w-auto" data-testid="button-start-assessment">
              ابدأ التقييم
              <ChevronLeft className="mr-2 w-4 h-4" />
            </Button>
          </Link>
          <Link href="/pharmacist">
            <Button size="lg" variant="outline" className="w-full sm:w-auto" data-testid="button-pharmacist-mode">
              وضع الصيدلاني
            </Button>
          </Link>
        </div>
        <p className="text-xs text-muted-foreground mt-4">
          ليس أداة تشخيص طبي — استشر دائماً مختصاً في الرعاية الصحية.
        </p>
      </section>

      <section className="max-w-4xl mx-auto w-full">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {FEATURES.map(({ icon: Icon, label, desc }) => (
            <Card key={label} className="border-border hover:border-primary/40 transition-colors">
              <CardContent className="p-5">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-bold text-sm mb-1">{label}</h3>
                <p className="text-xs text-muted-foreground">{desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="max-w-2xl mx-auto w-full">
        <div className="bg-primary/5 border border-primary/20 rounded-xl p-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-sm mb-1">إخلاء المسؤولية الطبية</h3>
              <p className="text-xs text-muted-foreground">
                ميديتشيك هو أداة دعم قرار ولا يُقدّم تشخيصاً طبياً.
                لا يُغني عن استشارة الطبيب المتخصص. لا تستخدم هذه الأداة في حالات الطوارئ —
                اتصل بالإسعاف فوراً إذا كنت تعاني من حالة تهدد حياتك.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
