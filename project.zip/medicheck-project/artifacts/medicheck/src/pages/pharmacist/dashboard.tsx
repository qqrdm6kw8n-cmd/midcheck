import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useListAssessments, useGetAssessmentSummary } from "@workspace/api-client-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell, ResponsiveContainer, Legend
} from "recharts";
import { Activity, Users, AlertTriangle, UserCheck, ChevronLeft, Stethoscope } from "lucide-react";

const SEVERITY_COLORS = {
  mild: "#10B981",
  moderate: "#F59E0B",
  severe: "#EF4444",
};

const SEVERITY_LABELS: Record<string, string> = {
  mild: "خفيفة",
  moderate: "متوسطة",
  severe: "شديدة",
};

const CONDITION_LABELS: Record<string, string> = {
  "Seasonal Allergy": "حساسية موسمية",
  "Common Cold": "نزلة برد",
  "Influenza": "إنفلونزا",
};

const CONDITION_COLORS = ["#2563EB", "#10B981", "#F59E0B"];

function StatCard({ label, value, icon: Icon, color }: { label: string; value: number | undefined; icon: typeof Activity; color: string }) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{label}</p>
            {value === undefined ? (
              <Skeleton className="h-8 w-12 mt-1" />
            ) : (
              <p className="text-3xl font-extrabold mt-1" style={{ color }}>{value}</p>
            )}
          </div>
          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: `${color}20` }}>
            <Icon className="w-6 h-6" style={{ color }} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function PharmacistDashboard() {
  const { data: summary, isLoading: summaryLoading } = useGetAssessmentSummary();
  const { data: assessments, isLoading: assessmentsLoading } = useListAssessments();

  const recentList = assessments?.slice(0, 8) || [];

  const conditionData = (summary?.conditionBreakdown || []).map(item => ({
    ...item,
    condition: CONDITION_LABELS[item.condition] || item.condition,
  }));

  const severityData = (summary?.severityBreakdown || []).map(item => ({
    ...item,
    severity: SEVERITY_LABELS[item.severity] || item.severity,
  }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight flex items-center gap-2">
          <Stethoscope className="w-6 h-6 text-primary" />
          لوحة الصيدلاني
        </h1>
        <p className="text-muted-foreground mt-1">نظرة عامة على جميع تقييمات المرضى</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="إجمالي التقييمات" value={summary?.totalAssessments} icon={Users} color="#2563EB" />
        <StatCard label="اليوم" value={summary?.todayCount} icon={Activity} color="#10B981" />
        <StatCard label="الحالات الشديدة" value={summary?.severeCount} icon={AlertTriangle} color="#EF4444" />
        <StatCard label="تحتاج إحالة" value={summary?.referralCount} icon={UserCheck} color="#F59E0B" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">توزيع الحالات</CardTitle>
            <CardDescription>أكثر الحالات شيوعاً في جميع التقييمات</CardDescription>
          </CardHeader>
          <CardContent>
            {summaryLoading ? (
              <Skeleton className="h-48 w-full" />
            ) : conditionData.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={conditionData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                  <XAxis dataKey="condition" tick={{ fontSize: 11, fontFamily: "Cairo" }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="count" name="التقييمات" radius={[4, 4, 0, 0]}>
                    {conditionData.map((_, index) => (
                      <Cell key={index} fill={CONDITION_COLORS[index % CONDITION_COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">
                لا توجد بيانات بعد
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">توزيع الشدة</CardTitle>
            <CardDescription>توزيع مستويات شدة الأعراض</CardDescription>
          </CardHeader>
          <CardContent>
            {summaryLoading ? (
              <Skeleton className="h-48 w-full" />
            ) : severityData.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={severityData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    dataKey="count"
                    nameKey="severity"
                    label={({ severity, percent }) => `${severity} ${Math.round(percent * 100)}%`}
                    labelLine={false}
                  >
                    {severityData.map((entry, index) => {
                      const originalSev = Object.entries(SEVERITY_LABELS).find(([, v]) => v === entry.severity)?.[0] || "";
                      return <Cell key={index} fill={SEVERITY_COLORS[originalSev as keyof typeof SEVERITY_COLORS] || "#9CA3AF"} />;
                    })}
                  </Pie>
                  <Legend />
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-48 flex items-center justify-center text-sm text-muted-foreground">
                لا توجد بيانات بعد
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">آخر التقييمات</CardTitle>
          <CardDescription>أحدث تقييمات الأعراض للمرضى</CardDescription>
        </CardHeader>
        <CardContent>
          {assessmentsLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}
            </div>
          ) : recentList.length === 0 ? (
            <div className="py-8 text-center text-sm text-muted-foreground">
              لا توجد تقييمات بعد. يمكن للمرضى إجراء تقييم من الصفحة الرئيسية.
            </div>
          ) : (
            <div className="divide-y">
              {recentList.map((assessment) => {
                const results = assessment.results as Array<{ condition: string; probability: number }>;
                const topCondition = results?.length > 0 ? results.reduce((a, b) => a.probability > b.probability ? a : b) : null;
                const sevColor = SEVERITY_COLORS[assessment.overallSeverity as keyof typeof SEVERITY_COLORS] || "#9CA3AF";
                const patInfo = assessment.patientInfo as { age?: number; gender?: string };
                const genderLabel: Record<string, string> = { male: "ذكر", female: "أنثى", other: "آخر" };

                return (
                  <Link
                    key={assessment.id}
                    href={`/pharmacist/assessment/${assessment.id}`}
                    className="flex items-center justify-between py-3 hover:bg-muted/50 px-2 -mx-2 rounded-lg transition-colors cursor-pointer"
                    data-testid={`assessment-row-${assessment.id}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: sevColor }} />
                      <div>
                        <p className="text-sm font-bold">
                          {patInfo?.gender ? genderLabel[patInfo.gender] || patInfo.gender : "مريض"}{patInfo?.age ? `، ${patInfo.age} سنة` : ""}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {topCondition ? `${CONDITION_LABELS[topCondition.condition] || topCondition.condition} (${topCondition.probability}%)` : "لا توجد نتائج"}
                          {" · "}
                          {new Date(assessment.createdAt).toLocaleDateString("ar-SA")}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {assessment.referralRecommended && (
                        <Badge variant="destructive" className="text-xs">إحالة</Badge>
                      )}
                      <Badge variant="outline" className="text-xs">{SEVERITY_LABELS[assessment.overallSeverity] || assessment.overallSeverity}</Badge>
                      <ChevronLeft className="w-4 h-4 text-muted-foreground" />
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
