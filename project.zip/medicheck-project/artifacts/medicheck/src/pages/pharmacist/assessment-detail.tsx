import { useLocation, useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useGetAssessment, getGetAssessmentQueryKey } from "@workspace/api-client-react";
import {
  ArrowRight, AlertTriangle, CheckCircle, XCircle, User, Heart, Stethoscope, Pill
} from "lucide-react";

const SEVERITY_CONFIG = {
  mild: { label: "خفيفة", color: "text-green-600", bg: "bg-green-50 border-green-200 dark:bg-green-950/30 dark:border-green-800", Icon: CheckCircle },
  moderate: { label: "متوسطة", color: "text-yellow-600", bg: "bg-yellow-50 border-yellow-200 dark:bg-yellow-950/30 dark:border-yellow-800", Icon: AlertTriangle },
  severe: { label: "شديدة", color: "text-destructive", bg: "bg-red-50 border-red-200 dark:bg-red-950/30 dark:border-red-800", Icon: XCircle },
};

const CONDITION_LABELS: Record<string, string> = {
  "Seasonal Allergy": "حساسية موسمية",
  "Common Cold": "نزلة برد",
  "Influenza": "إنفلونزا",
};

const INTERACTION_BG = {
  mild: "border-blue-200 bg-blue-50 dark:bg-blue-950/20 dark:border-blue-800",
  moderate: "border-yellow-200 bg-yellow-50 dark:bg-yellow-950/20 dark:border-yellow-800",
  severe: "border-red-200 bg-red-50 dark:bg-red-950/20 dark:border-red-800",
};

const SYMPTOM_LABELS: Record<string, string> = {
  fever: "حمى", runnyNose: "سيلان الأنف", nasalCongestion: "احتقان الأنف",
  sneezing: "عطس", itchyNose: "حكة أنف", itchyEyes: "حكة عيون", wateryEyes: "دموع عيون",
  soreThroat: "التهاب حلق", cough: "سعال", shortnessOfBreath: "ضيق تنفس",
  wheezing: "صفير تنفس", headache: "صداع", musclePain: "آلام عضلات",
  fatigue: "إرهاق", chills: "قشعريرة", chestPain: "ألم صدر",
};

const GENDER_LABELS: Record<string, string> = { male: "ذكر", female: "أنثى", other: "آخر" };
const SEVERITY_INT_LABELS: Record<string, string> = { mild: "خفيف", moderate: "متوسط", severe: "شديد" };
const REDFLAG_LABELS: Record<string, string> = {
  "Chest Pain": "ألم في الصدر", "Shortness of Breath": "ضيق التنفس",
  "Severe Wheezing": "صفير تنفس شديد", "Abnormal Sputum Color": "لون بلغم غير طبيعي",
};

export default function AssessmentDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const numId = parseInt(id, 10);

  const { data: assessment, isLoading } = useGetAssessment(numId, {
    query: { enabled: !!numId, queryKey: getGetAssessmentQueryKey(numId) },
  });

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  if (!assessment) {
    return (
      <div className="max-w-3xl mx-auto text-center py-16">
        <p className="text-muted-foreground">التقييم غير موجود.</p>
        <Button className="mt-4" onClick={() => setLocation("/pharmacist")}>العودة للوحة التحكم</Button>
      </div>
    );
  }

  const patInfo = assessment.patientInfo as Record<string, unknown>;
  const chronic = assessment.chronicDiseases as Record<string, boolean>;
  const symptoms = assessment.symptoms as Record<string, unknown>;
  const results = assessment.results as Array<{ condition: string; probability: number; severity: string; suggestedTreatments: string[]; warnings: string[] }>;
  const interactions = assessment.interactions as Array<{ drugA: string; drugB: string; severity: string; message: string }>;
  const sevCfg = SEVERITY_CONFIG[assessment.overallSeverity as keyof typeof SEVERITY_CONFIG] || SEVERITY_CONFIG.mild;
  const SevIcon = sevCfg.Icon;

  const chronicList = Object.entries(chronic).filter(([, v]) => v).map(([k]) =>
    k.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase())
  );

  const symptomList = Object.entries(symptoms)
    .filter(([k, v]) => v === true && !["symptomDurationDays", "symptomSeverity"].includes(k))
    .map(([k]) => SYMPTOM_LABELS[k] || k);

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => setLocation("/pharmacist")} data-testid="button-back">
          <ArrowRight className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-xl font-extrabold">تقييم رقم #{assessment.id}</h1>
          <p className="text-xs text-muted-foreground">{new Date(assessment.createdAt).toLocaleString("ar-SA")}</p>
        </div>
        <div className="mr-auto flex gap-2">
          {assessment.referralRecommended && <Badge variant="destructive">يحتاج إحالة</Badge>}
          <Badge variant="outline" className={sevCfg.color}>{sevCfg.label}</Badge>
        </div>
      </div>

      <div className={`border rounded-xl p-4 ${sevCfg.bg}`}>
        <div className="flex items-center gap-2 mb-1">
          <SevIcon className={`w-5 h-5 ${sevCfg.color}`} />
          <span className={`font-bold ${sevCfg.color}`}>الشدة الإجمالية: {sevCfg.label}</span>
        </div>
        {assessment.referralRecommended && (
          <p className="text-sm font-bold text-destructive mt-2">
            يُوصى بإحالة هذا المريض إلى طبيب مختص.
          </p>
        )}
        {(assessment.redFlagsDetected as string[]).length > 0 && (
          <div className="mt-2 space-y-1">
            {(assessment.redFlagsDetected as string[]).map(flag => (
              <p key={flag} className="text-xs flex items-center gap-1.5 text-destructive">
                <span className="w-1.5 h-1.5 rounded-full bg-destructive" />
                {REDFLAG_LABELS[flag] || flag}
              </p>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2"><User className="w-4 h-4 text-primary" /> بيانات المريض</CardTitle>
          </CardHeader>
          <CardContent className="text-sm space-y-1">
            {patInfo.age && <p>العمر: <strong>{String(patInfo.age)} سنة</strong></p>}
            {patInfo.gender && <p>الجنس: <strong>{GENDER_LABELS[String(patInfo.gender)] || String(patInfo.gender)}</strong></p>}
            {patInfo.weight && <p>الوزن: <strong>{String(patInfo.weight)} كجم</strong></p>}
            {patInfo.isPregnant && <p className="text-amber-600 font-bold">حامل</p>}
            {patInfo.isSmoker && <p className="text-orange-600 font-semibold">مدخّن</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2"><Heart className="w-4 h-4 text-primary" /> الأمراض المزمنة</CardTitle>
          </CardHeader>
          <CardContent>
            {chronicList.length === 0 ? (
              <p className="text-sm text-muted-foreground">لا يوجد</p>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {chronicList.map(c => <Badge key={c} variant="secondary" className="text-xs">{c}</Badge>)}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2"><Stethoscope className="w-4 h-4 text-primary" /> الأعراض المُبلَّغ عنها</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {symptomList.map(s => <Badge key={s} variant="outline" className="text-xs">{s}</Badge>)}
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            {symptoms.temperature && <p>الحرارة: <strong>{String(symptoms.temperature)}°م</strong></p>}
            {symptoms.symptomDurationDays && <p>المدة: <strong>{String(symptoms.symptomDurationDays)} أيام</strong></p>}
            {symptoms.symptomSeverity && <p>الشدة: <strong>{SEVERITY_INT_LABELS[String(symptoms.symptomSeverity)] || String(symptoms.symptomSeverity)}</strong></p>}
            {symptoms.dryOrProductiveCough && <p>نوع السعال: <strong>{symptoms.dryOrProductiveCough === "dry" ? "جاف" : "مع بلغم"}</strong></p>}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2"><Pill className="w-4 h-4 text-primary" /> الأدوية والحساسية</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <p className="text-xs font-bold text-muted-foreground mb-1.5 uppercase tracking-wide">الأدوية الحالية</p>
            {(assessment.currentMedications as string[]).length === 0 ? (
              <p className="text-sm text-muted-foreground">لا يوجد</p>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {(assessment.currentMedications as string[]).map(m => <Badge key={m} variant="secondary" className="text-xs">{m}</Badge>)}
              </div>
            )}
          </div>
          <div>
            <p className="text-xs font-bold text-muted-foreground mb-1.5 uppercase tracking-wide">الحساسية الدوائية</p>
            {(assessment.drugAllergies as string[]).length === 0 ? (
              <p className="text-sm text-muted-foreground">لا يوجد</p>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {(assessment.drugAllergies as string[]).map(a => <Badge key={a} variant="destructive" className="text-xs">{a}</Badge>)}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {results.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">نتائج تحليل الحالة</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {results.map(result => (
              <div key={result.condition}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-bold">{CONDITION_LABELS[result.condition] || result.condition}</span>
                  <span className="text-sm font-extrabold text-primary">{result.probability}%</span>
                </div>
                <Progress value={result.probability} className="h-1.5" />
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {interactions.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2 text-destructive">
              <AlertTriangle className="w-4 h-4" /> تنبيهات التفاعلات الدوائية
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {interactions.map((inter, i) => (
              <div key={i} className={`border rounded-lg p-3 text-sm ${INTERACTION_BG[inter.severity as keyof typeof INTERACTION_BG] || ""}`}>
                <p className="font-bold">{inter.drugA} + {inter.drugB} <Badge variant="outline" className="mr-1 text-xs">{SEVERITY_INT_LABELS[inter.severity] || inter.severity}</Badge></p>
                <p className="text-xs opacity-80 mt-1">{inter.message}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
