import { pgTable, text, serial, timestamp, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const assessmentsTable = pgTable("assessments", {
  id: serial("id").primaryKey(),
  patientInfo: jsonb("patient_info").notNull(),
  chronicDiseases: jsonb("chronic_diseases").notNull(),
  symptoms: jsonb("symptoms").notNull(),
  currentMedications: jsonb("current_medications").notNull(),
  drugAllergies: jsonb("drug_allergies").notNull(),
  results: jsonb("results").notNull(),
  interactions: jsonb("interactions").notNull(),
  redFlagsDetected: jsonb("red_flags_detected").notNull(),
  referralRecommended: boolean("referral_recommended").notNull().default(false),
  overallSeverity: text("overall_severity").notNull().default("mild"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAssessmentSchema = createInsertSchema(assessmentsTable).omit({ id: true, createdAt: true });
export type InsertAssessment = z.infer<typeof insertAssessmentSchema>;
export type Assessment = typeof assessmentsTable.$inferSelect;
