# MediCheck

A smart healthcare web application for symptom assessment, drug interaction checking, and pharmacist review — built for patients and pharmacists.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/medicheck run dev` — run the frontend (port 23105)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite, Tailwind CSS, shadcn/ui, Wouter (routing), Recharts
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — single source of truth for all API contracts
- `lib/db/src/schema/` — database tables (medications, drug_interactions, assessments)
- `artifacts/api-server/src/routes/` — API route handlers (medications, interactions, assessments)
- `artifacts/api-server/src/lib/analysis-engine.ts` — server-side rule-based symptom scoring
- `artifacts/medicheck/src/lib/analysis-engine.ts` — client-side rule-based symptom analysis
- `artifacts/medicheck/src/lib/assessment-context.tsx` — React context for multi-step wizard state
- `artifacts/medicheck/src/pages/assessment/` — 5-step assessment wizard pages
- `artifacts/medicheck/src/pages/pharmacist/` — pharmacist dashboard and assessment detail

## Architecture decisions

- Analysis engine runs client-side for instant feedback, then results are persisted server-side when the user saves
- Multi-step wizard state stored in React Context (AssessmentProvider), not URL params
- Drug interactions checked via API (POST /api/interactions/check) which matches against a seeded database
- All API contracts defined in OpenAPI spec first, then generated into typed hooks and Zod schemas
- Frontend uses generated hooks from `@workspace/api-client-react` — no raw fetch calls

## Product

**Patient Flow:**
1. Landing Page → Disclaimer → Patient Info → Chronic Conditions → Symptoms → Medications → Results
2. Results page shows: condition probabilities (Seasonal Allergy / Common Cold / Influenza), severity level (green/yellow/red), suggested OTC treatments, drug interaction warnings, red flag detection, physician referral recommendation

**Pharmacist Mode:**
- Dashboard with aggregate stats (total assessments, today's count, severe cases, referral count)
- Conditions breakdown bar chart + severity distribution pie chart (Recharts)
- Recent assessments list with clickable rows
- Individual assessment detail view with full patient data

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Always run codegen after changing the OpenAPI spec: `pnpm --filter @workspace/api-spec run codegen`
- Analysis engine exists in both client (src/lib/analysis-engine.ts) and server — keep them in sync
- DB tables use snake_case column names, Drizzle maps to camelCase in TypeScript

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
